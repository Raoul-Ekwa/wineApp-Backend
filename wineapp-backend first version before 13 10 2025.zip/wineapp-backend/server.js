const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const { connectDB, sequelize } = require("./config/db.js");

const authRoutes = require("./routes/authRoutes.js");
const productRoutes = require("./routes/productRoutes.js");
const orderRoutes = require("./routes/orderRoutes.js");

dotenv.config();
connectDB();

const app = express();
app.use(cors());
app.use(express.json());

// Routes
app.use("/api/auth", authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/orders", orderRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, async () => {
  console.log(`🚀 Serveur sur http://localhost:${PORT}`);
  try {
    await sequelize.sync({ alter: true }); // créer les tables si nécessaire
    console.log("✅ Tables PostgreSQL synchronisées");
  } catch (err) {
    console.error("❌ Erreur lors de la synchronisation des tables :", err);
  }
});


