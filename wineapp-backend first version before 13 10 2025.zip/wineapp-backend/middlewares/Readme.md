\# Middleware



Ce sont des fonctions intermédiaires qui s’exécutent avant d’arriver à la route finale.



Exemple d’usages :



* Vérifier si un utilisateur est connecté (authentification).
* Logger les requêtes (audit).
* Gérer les erreurs globalement.
