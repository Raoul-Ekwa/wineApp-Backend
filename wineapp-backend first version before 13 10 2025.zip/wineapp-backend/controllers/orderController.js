const Order = require("../models/Order.js");
const Product = require("../models/Product.js");

// ✅ Créer une commande
const createOrder = async (req, res) => {
  try {
    const { userId, productId, quantity } = req.body;

    // Vérifier si le produit existe
    const product = await Product.findByPk(productId);
    if (!product) {
      return res.status(404).json({ message: "Produit non trouvé" });
    }

    // Vérifier stock
    if (product.stock < quantity) {
      return res.status(400).json({ message: "Stock insuffisant" });
    }

    // Calcul du prix total
    const totalPrice = product.price * quantity;

    // Création de la commande
    const order = await Order.create({
      userId,
      productId,
      quantity,
      totalPrice
    });

    // Mise à jour du stock produit
    product.stock -= quantity;
    await product.save();

    res.status(201).json(order);
  } catch (err) {
    res.status(500).json({ message: "Erreur serveur" });
  }
};

// ✅ Récupérer toutes les commandes
const getOrders = async (req, res) => {
  try {
    const orders = await Order.findAll({
      include: [
        { model: require("../models/User.js"), as: "User" },
        { model: require("../models/Product.js"), as: "Product" }
      ]
    });
    res.json(orders);
  } catch (err) {
    console.error("❌ Erreur getOrders:", err);
    res.status(500).json({ message: "Erreur serveur" });
  }
};


module.exports = { createOrder, getOrders };
