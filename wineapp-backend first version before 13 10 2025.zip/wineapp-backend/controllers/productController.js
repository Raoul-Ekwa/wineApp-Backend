const Product = require("../models/Product.js");

// ✅ Récupérer tous les produits
const getProducts = async (req, res) => {
  try {
    const products = await Product.findAll();
    res.json(products);
  } catch (err) {
    res.status(500).json({ message: "Erreur serveur" });
  }
};

// ✅ Ajouter un produit
const createProduct = async (req, res) => {
  try {
    const { name, description, price, image, stock } = req.body;

    if (!name || !price) {
      return res.status(400).json({ message: "Nom et prix sont obligatoires" });
    }

    const product = await Product.create({
      name,
      description,
      price,
      image,
      stock,
    });

    res.status(201).json(product);
  } catch (err) {
    res.status(500).json({ message: "Erreur serveur" });
  }
};

module.exports = { getProducts, createProduct };

