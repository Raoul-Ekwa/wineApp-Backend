\# Logique métier



&nbsp;C’est le cœur de ton application, les règles spécifiques à ton projet.



Exemple pour TheWineApp :



* Vérifier que le stock est suffisant avant de valider une commande.
* Calculer une remise si un client achète plus de 6 bouteilles.
* Générer une facture après paiement.
