const express = require("express");
const { registerUser, loginUser } = require("../controllers/authController.js");

const router = express.Router();

router.post("/register", registerUser);  // 🔹 doit être une fonction
router.post("/login", loginUser);

module.exports = router;


