\# Routes API



C’est l’entrée de ton serveur.



Chaque route correspond à une action que le client (ton app mobile TheWineApp) peut demander.



Exemple :



* GET /vins → Liste des vins
* POST /auth/login → Connexion utilisateur
* POST /commandes → Créer une commande
