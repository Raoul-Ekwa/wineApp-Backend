\# Connexion DB



C’est le pont entre ton serveur et ta base de données.



* Exemple : connecter ton serveur Node.js à MongoDB, MySQL ou PostgreSQL.
* Sans ça, ton serveur ne peut pas lire ni écrire des infos (ex : stock de vins, comptes clients).
