const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db.js");
const User = require("./User.js");
const Product = require("./Product.js");

const Order = sequelize.define("Order", {
  quantity: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 1,
  },
  totalPrice: {
    type: DataTypes.FLOAT,
    allowNull: false,
  },
});

// Relations
Order.belongsTo(User, { as: "User", foreignKey: "userId", onDelete: "CASCADE" });
Order.belongsTo(Product, { as: "Product", foreignKey: "productId", onDelete: "CASCADE" });

module.exports = Order;


