const { DataTypes } = require("sequelize");
const { sequelize } = require("../config/db.js");

const Product = sequelize.define("Product", {
  name: { type: DataTypes.STRING, allowNull: false },
  description: DataTypes.TEXT,
  price: { type: DataTypes.FLOAT, allowNull: false },
  image: DataTypes.STRING,
  stock: { type: DataTypes.INTEGER, defaultValue: 0 },
});

module.exports = Product;
