\# Schémas DB (ou Modèles)



C’est la structure des données dans ta base.



* Définit comment sont organisées les infos : champs, types, contraintes.
* Exemple : un vin a un nom, un prix, une année, un stock.
